"""
utils for DiffPIR
"""
